#!/bin/sh
valgrind --tool=memcheck --leak-check=full --leak-resolution=high --error-limit=no --undef-value-errors=yes  --log-file=valgrind.log  ./sapp
